var passgen__gui___about_dialog_8c =
[
    [ "gtkMenuItemHelpAboutHide", "passgen__gui___about_dialog_8c.html#ada405bcdf3e8b35a7ee13a4282016a6d", null ],
    [ "gtkMenuItemHelpAboutShow", "passgen__gui___about_dialog_8c.html#a8a63e88d977cf0bb189ce13b40eee6ca", null ]
];