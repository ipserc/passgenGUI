var searchData=
[
  ['buffer_538',['buffer',['../structpsg_params__t.html#a0e0ff970abe71c59dd1d3334fa840ea6',1,'psgParams_t']]]
];
