var searchData=
[
  ['version_676',['VERSION',['../passgen_8c.html#a1c6d5de492ac61ad29aec7aa9a436bbf',1,'VERSION():&#160;passgen.c'],['../randomize_8c.html#a1c6d5de492ac61ad29aec7aa9a436bbf',1,'VERSION():&#160;randomize.c']]],
  ['very_5flong_5fsize_677',['VERY_LONG_SIZE',['../passgen_8h.html#aa067b7f8603a0adc8e045ca5575e2eb2',1,'passgen.h']]]
];
