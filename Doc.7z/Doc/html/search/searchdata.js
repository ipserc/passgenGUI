var indexSectionsWithContent =
{
  0: "_abcdefghilmnoprstuvw",
  1: "pu",
  2: "pr",
  3: "_abcdefghilmnoprstw",
  4: "_abceghlnpsuv",
  5: "p",
  6: "cgpsu",
  7: "bcghlmnpsu",
  8: "_aceflmnpstuvw"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "typedefs",
  6: "enums",
  7: "enumvalues",
  8: "defines"
};

var indexSectionLabels =
{
  0: "All",
  1: "Data Structures",
  2: "Files",
  3: "Functions",
  4: "Variables",
  5: "Typedefs",
  6: "Enumerations",
  7: "Enumerator",
  8: "Macros"
};

