var searchData=
[
  ['user_5fdata_5ft_353',['user_data_t',['../structuser__data__t.html',1,'']]]
];
